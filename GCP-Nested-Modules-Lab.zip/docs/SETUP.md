# GCP setup checklist
1. Bootstrap GCS state bucket with versioning and restricted IAM; configure backend.tf.
2. Enable Compute Engine and Cloud Load Balancing APIs.
3. Configure GitHub Workload Identity Federation pool/provider with conditions restricted to repository and branch/environment; allow deployer service account impersonation.
4. Add GitHub variables: `GCP_PROJECT_ID`, `GCP_REGION`, `GCP_ZONE`, `GCP_WIF_PROVIDER`, `GCP_DEPLOYER_SERVICE_ACCOUNT`.
5. Review firewall health-check source ranges for selected LB product; sample uses standard Google health check ranges.
6. Run fmt/init/validate/plan, verify APIs/permissions and estimated costs, then apply.
7. Verify forwarding-rule IP returns NGINX and backend health is healthy; destroy workload afterward.
Note: the load balancer module is a starter pattern. GCP has multiple LB products and regional/global variants with differing proxy subnet and firewall requirements; validate the chosen product against current GCP docs before apply.
