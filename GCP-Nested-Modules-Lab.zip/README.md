# GCP Nested Modules Lab (Phase 3 scaffold)
Status: **starter scaffold; not yet validated/deployed**.

## Architecture
GitHub Actions OIDC → Workload Identity Federation/service account → Terraform:
custom VPC → subnet → firewall → Compute Engine VM (NGINX startup script) → external HTTP load balancer (health check/backend/URL map/proxy/forwarding rule).

## Bootstrap
Create a GCS state bucket and Workload Identity Federation pool/provider + deployer service account before workflow. Grant bucket access and service-account impersonation. Enable Compute and Cloud Load Balancing APIs.

## Validation
From `terraform/GCP`: `terraform fmt -recursive`, `terraform init -backend=false`, `terraform validate`.
Configure backend and project/region/zone/identity before plan.
